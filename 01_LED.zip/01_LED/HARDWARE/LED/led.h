#ifndef __LED_L
#define __LED_L

void LED_Init(void);


#endif
