#include "led.h"
#include "stm32f10x.h"


void LED_Init()
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);		// ���ȿ���GPIO��ʱ��
	
	GPIO_InitTypeDef GPIOC_13_InitStructure;
	
	GPIOC_13_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOC_13_InitStructure.GPIO_Pin = GPIO_Pin_13;
	GPIOC_13_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	
	GPIO_Init(GPIOC, &GPIOC_13_InitStructure);
	GPIO_SetBits(GPIOC, GPIO_Pin_13);
	
}
